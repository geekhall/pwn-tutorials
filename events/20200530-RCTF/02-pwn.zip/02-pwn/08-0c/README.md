# 0c

Zero-featured TypeScript on JVM
